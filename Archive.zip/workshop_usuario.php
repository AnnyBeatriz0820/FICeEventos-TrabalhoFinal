
          <!-- PARTE PRINCIPAL DA PAGINA ONDE DEVE SER ADICIONADO O CONTEUDO-->
          <div class='container'>
          <form method="post" action="index.php">
<div class="form-group">
    
  <label class="col-md-12 control-label" for="selectbasic">Escolher Tema<h11>*</h11></label>
  
  <div class="col-md-12">
    <select required id="Workshop" name="Workshop" class="form-control">
      <option value="WorkshopEst">Workshop  Estudantil</option>
      <option value="WorkshopBAI">Workshop Brasileiro de Avaliação de Impacto</option>
      <option value="WorkshopCGE">Workshop Cearense de Gestão do Esporte</option>
      <option value="WorkshopC">Workshop da Ciência</option>
      <option value="WorkshopS">Workshop da Saúde</option>
      <option value="WorkshopA">Workshop das Águas</option>
      <option value="WorkshopEd">Workshop de Educação</option>
      <option value="WorkshopTI">Workshop de Técnologia</option>
      <option value="WorkshopZ">Workshop de Pesquisa</option>
      <option value="WorkshopE">Workshop do Esporte</option>
      <option value="WorkshopIACN">Workshop Internacional Artefatos da Cultura Negra</option>
      <option value="WorkshopSM">Workshop Internacional de Saúde Mental</option>
      
    </select>
  </div>
  </div>
 
<!-- Button (Double) -->
<div class="form-group">
  <label class="col-md-2 control-label" for="Cadastrar"></label>
  <div class="col-md-8">
    <button id="Cadastrar" name="Cadastrar" class="btn btn-success" type="Submit">Inscrever no Workshop</button>
    <button id="Cancelar" name="Cancelar" class="btn btn-danger" type="Reset">Cancelar Inscrição</button>
  </div>
</div>
</fieldset>
</fieldset>
</form>
  
</div>


</div></div></div></div>

          <!-- FIM PARTE PRINCIPAL DA PAGINA ONDE DEVE SER ADICIONADO O CONTEUDO-->

  