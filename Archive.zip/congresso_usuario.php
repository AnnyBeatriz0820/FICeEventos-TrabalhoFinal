
<!-- PARTE PRINCIPAL DA PAGINA ONDE DEVE SER ADICIONADO O CONTEUDO-->
          <div class="container">


          <form method="post" action="index.php">


<div class="form-group">
    
  <label class="col-md-6 control-label" for="selectbasic">Escolher Tema<h11>*</h11></label>
  
  <div class="col-md-12">
    <select required id="Curso" name="Curso" class="form-control">
      <option value="CongressoEst">Congresso  Estudantil</option>
      <option value="CongressoBAI">Congresso Brasileiro de Avaliação de Impacto</option>
      <option value="CongressoCGE">Congresso Cearense de Gestão do Esporte</option>
      <option value="CongressoC">Congresso da Ciência</option>
      <option value="CongressoS">Congresso da Saúde</option>
      <option value="CongressoA">Congresso das Águas</option>
      <option value="CongressoEd">Congresso de Educação</option>
      <option value="CongressoTI">Congresso de Técnicos em Informática</option>
      <option value="CongressoZ">Congresso de Zootecnia</option>
      <option value="CongressoE">Congresso do Esporte</option>
      <option value="CongressoIACN">Congresso Internacional Artefatos da Cultura Negra</option>
      <option value="CongressoSM">Congresso Internacional de Saúde Mental</option>    
    </select>
  </div>
  </div>
<!-- Button (Double) -->
<div class="form-group">
  <label class="col-md-2 control-label" for="Cadastrar"></label>
  <div class="col-md-8">
    <button id="Cadastrar" name="Cadastrar" class="btn btn-success" type="Submit">Inscrever</button>
    <button id="Cancelar" name="Cancelar" class="btn btn-danger" type="Reset">Cancelar Inscrição</button>
  </div>
</div>
</fieldset>
</form>       
</div>
          <!-- FIM PARTE PRINCIPAL DA PAGINA ONDE DEVE SER ADICIONADO O CONTEUDO-->