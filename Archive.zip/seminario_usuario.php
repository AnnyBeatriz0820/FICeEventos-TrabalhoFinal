
          <!-- PARTE PRINCIPAL DA PAGINA ONDE DEVE SER ADICIONADO O CONTEUDO-->
<div class="container">
          <form method="post" action="index.php">

<div class="form-group">
    
  <label class="col-md-12 control-label" for="selectbasic">Escolher Seminário<h11>*</h11></label>
  
  <div class="col-md-12">
    <select required id="Seminario" name="Seminario" class="form-control">
      <option value="SeminarioC">Seminário da Ciência</option>
      <option value="SeminarioA">Seminário das Águas</option>
      <option value="SeminarioCom">Seminário de Comunicação</option>
      <option value="SeminarioEd">Seminário de Educação </option>
      <option value="SeminarioEt">Seminário de Ética</option>
      <option value="SeminarioGe">Seminário de Geografia</option>
      <option value="SeminarioPPG">Seminário de Pesquisa Pós Graduação</option>
      <option value="SeminarioIV">Seminário Internacional de Violão</option>
      <option value="SeminarioMA">Seminário Meio Ambiente</option>
      <option value="SeminarioSPP">Seminário Sobre Políticas Públicas</option>
         </select>
  </div>
  </div>
  
<!-- Button (Double) -->
<div class="form-group">
  <label class="col-md-2 control-label" for="Cadastrar"></label>
  <div class="col-md-8">
    <button id="Cadastrar" name="Cadastrar" class="btn btn-success" type="Submit">Inscrever</button>
    <button id="Cancelar" name="Cancelar" class="btn btn-danger" type="Reset">Cancelar Inscrição</button>
  </div>
</div>
</fieldset>
</form>

</div></div></div></div>
          <!-- FIM PARTE PRINCIPAL DA PAGINA ONDE DEVE SER ADICIONADO O CONTEUDO-->
