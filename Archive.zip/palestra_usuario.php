
          <!-- PARTE PRINCIPAL DA PAGINA ONDE DEVE SER ADICIONADO O CONTEUDO-->
 <div class='container'>
          <form action="index.php" method="post">
 
<div class="form-group">
  <label class="col-md-12 control-label" for="Nome">Tema da Palestra <h11>*</h11></label>  
  <div class="col-md-8">
  <input id="Palestra" name="Palestra" placeholder="" class="form-control input-md" required="" type="text">
  </div>
</div>

 
<!-- Button (Double) -->
<div class="form-group">
  <label class="col-md-3 control-label" for="Cadastrar"></label>
  <div class="col-md-8">
    <button id="Cadastrar" name="Cadastrar" class="btn btn-success" type="Submit">Inscrever</button>
    <button id="Cancelar" name="Cancelar" class="btn btn-danger" type="Reset">Cancelar Inscrição</button>
  </div>
</div>
</fieldset>
</form>
</div>

          <!-- FIM PARTE PRINCIPAL DA PAGINA ONDE DEVE SER ADICIONADO O CONTEUDO-->
