
          <form method="post" action="index.php">

<div class="form-group">
    
  <label class="col-md-6 control-label" for="selectbasic">Selecione seu Curso de Extensão<h11>*</h11></label>
  
  <div class="col-md-12">
    <select required id="Curso" name="Curso" class="form-control">
      <option value="Filosofia">Curso de Manutenção de Celulares</option>
      <option value="Filosofia">Curso de Música</option>
      <option value="Filosofia">Espanhol</option>
      <option value="Física">Estatística Aplicada a Educação com SPSS </option>
      <option value="Geografia">Física e Matemática</option>
      <option value="Física">Francês</option>
      <option value="Sociologia">Italiano</option>
      <option value="Literatura">Jiu-gítsu e muay  thai</option>
      <option value="Física">Judô</option>
      <option value="Inglês">Libras</option>
      <option value="Física">Pré-Enem</option>
       <option value="Matemática">Robóstica</option>
      <option value="História">História</option>
      <option value="Informática">Informática</option>
      <option value="Inglês">Inglês</option>
      <option value="Inglês">Libras</option>
      <option value="Português">Português</option>
      <option value="Química">Química</option>
    </select>
  </div>
  </div>
 
<!-- Button (Double) -->
<div class="form-group">
  <label class="col-md-2 control-label" for="Cadastrar"></label>
  <div class="col-md-8">
    <button id="Cadastrar" name="Cadastrar" class="btn btn-success" type="Submit">Inscrever</button>
    <button id="Cancelar" name="Cancelar" class="btn btn-danger" type="Reset">Cancelar Inscrição</button>
  </div>
</div>
</fieldset>
</form>

          <!-- FIM PARTE PRINCIPAL DA PAGINA ONDE DEVE SER ADICIONADO O CONTEUDO-->
