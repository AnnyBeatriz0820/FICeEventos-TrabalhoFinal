
          <form method="post" action="index.php">

<div class="form-group">
    
  <label class="col-md-2 control-label" for="selectbasic">Escolher Evento<h11>*</h11></label>
  
  <div class="col-md-3">
    <select required id="Evento" name="Evento" class="form-control">
      <option value="EventoEst">Evento  Estudantil</option>
      <option value="EventoBAI">Evento Brasileiro de Avaliação de Impacto</option>
      <option value="EventoCGE">Evento Cearense de Gestão do Esporte</option>
      <option value="EventoC">Evento da Ciência</option>
      <option value="EventoS">Evento da Saúde</option>
      <option value="EventoA">Evento das Águas</option>
      <option value="EventoEd">Evento de Educação</option>
      <option value="EventoTI">Evento de Técnicos em Informática</option>
      <option value="EventoZ">Evento de Público</option>
      <option value="EventoE">Evento do Esporte</option>
      <option value="EventoIACN">Evento Internacional da Cultura Negra</option>
      <option value="EventoSM">Evento Internacional de Saúde Mental</option>
      
    </select>
  </div>
  </div>
 
<!-- Button (Double) -->
<div class="form-group">
  <label class="col-md-2 control-label" for="Cadastrar"></label>
  <div class="col-md-8">
    <button id="Cadastrar" name="Cadastrar" class="btn btn-success" type="Submit">Inscrever no Evento </button>
    <button id="Cancelar" name="Cancelar" class="btn btn-danger" type="Reset">Cancelar Inscrição</button>
  </div>
</div>
</fieldset>
</form>
</div></div>
          <!-- FIM PARTE PRINCIPAL DA PAGINA ONDE DEVE SER ADICIONADO O CONTEUDO-->
