<div class='container'>
          <form action="index.php" method="post">

<div class="form-group">
    
  <label class="col-md-12 control-label" for="selectbasic">Escolher Oficina<h11>*</h11></label>
  
  <div class="col-md-12">
    <select required id="Oficina" name="Oficina" class="form-control">
      <option value="EducaçãoFísica">Educação Física</option>
      <option value="Filosofia">Filosofia</option>
      <option value="Física">Física</option>
      <option value="Geografia">Geografia</option>
      <option value="História">História</option>
      <option value="Informática">Informática</option>
      <option value="Inglês">Inglês</option>
      <option value="Libras">Libras</option>
      <option value="Literatura">Literatura</option>
      <option value="Matemática">Matemática</option>
      <option value="Português">Português</option>
      <option value="Química">Química</option>
      <option value="Sociologia">Sociologia</option>
    </select>
  </div>
  </div>
 
<!-- Button (Double) -->
<div class="form-group">
  <label class="col-md-2 control-label" for="Cadastrar"></label>
  <div class="col-md-8">
    <button id="Cadastrar" name="Cadastrar" class="btn btn-success" type="Submit">Inscrever</button>
    <button id="Cancelar" name="Cancelar" class="btn btn-danger" type="Reset">Cancelar Inscrição</button>
  </div>
</div>
</div> 
</fieldset>
</form>        